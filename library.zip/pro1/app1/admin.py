from django.contrib import admin
from app1.models import Book, UserInfo, Order

admin.site.register(Book)
admin.site.register(UserInfo)
admin.site.register(Order)
