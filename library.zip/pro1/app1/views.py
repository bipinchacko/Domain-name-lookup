from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from app1.forms import Bookform, UserForm, UserInfoForm, orderform
from app1.models import Book, UserInfo, Order
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from datetime import date
import datetime

from django.contrib.auth.models import User


def home(request):
    return render(request, "index.html")

@login_required
def user_logout(request):
    # Log out the user.
    logout(request)
    # Return to homepage.
    return HttpResponse("Logged out")



def uploadbook(request):
    form = Bookform()
    if (request.method == 'POST'):
        form = Bookform(request.POST, request.FILES)
        if (form.is_valid()):
            form.save()
            u = Book.objects.all()
            request.session['Book_id'] = 'Book_id'
            request.session['Bookname'] = 'Bookname'
        return render(request, 'allbooklist.html', {'lists': u})

    return render(request, 'uploadbook.html', {'form': form})


def User_register(request):
    registered = False

    if request.method == 'POST':

        # Get info from "both" forms
        # It appears as one form to the user on the .html page
        user_form = UserForm(data=request.POST)
        profile_form = UserInfoForm(data=request.POST)
        # Check to see both forms are valid

        if user_form.is_valid() and profile_form.is_valid():
            # Save User Form to Database
            user = user_form.save()

            # Hash the password
            user.set_password(user.password)

            # Update with Hashed password
            user.save()

            # Now we deal with the extra info!
            # Can't commit yet because we still need to manipulate
            a = int(request.POST['age'])
            profile = profile_form.save(commit=False)
            if a >= 50:
                profile.status = 'senior'
            else:
                profile.status = 'other'
            # Set One to One relationship between
            # UserForm and UserProfileInfoForm
            profile.user = user

            # Check if they provided a profile picture
            # Now save model
            profile.save()

            # Registration Successful!
            registered = True


        else:
            # One of the forms was invalid if this else gets called.
            print(user_form.errors, profile_form.errors)

    else:
        # Was not an HTTP post so we just render the forms as blank.
        user_form = UserForm()
        profile_form = UserInfoForm()

    # This is the render and context dictionary to feed
    # back to the registration.html file page.
    return render(request, 'registration/signup.html',
                  {'user_form': user_form,
                   'profile_form': profile_form,
                   'registered': registered})


def all_book(request, pk):
    instance = get_object_or_404(Book, pk=pk)

    context = {
        'instance': instance,
        'title': 'View Book'
    }
    return render(request, 'view_all_book.html', context)


def list(request):
    u = Book.objects.all()
    return render(request, 'allbooklist.html', {'lists': u})


def delete(request, pk):
    b = Book.objects.get(pk=pk)
    b.delete()

    return list(request)


def view(request, pk):
    instance = get_object_or_404(Book, pk=pk)

    context = {
        'instance': instance,

    }
    return render(request, 'view_all_book.html', context)


def edit(request, pk):
    view = Book.objects.get(pk=pk)
    form = Bookform(instance=view)
    if request.method == "POST":
        form = Bookform(instance=view)
        if form.is_valid():
            form.save(commit=True)
            return list(request)
        else:
            print('ERROR FORM INVALID')
    return render(request, 'edit.html', {'form': form})


def user_login(request):
    if request.method == 'POST':
        # First get the username and password supplied
        username = request.POST['username']
        password = request.POST['password']
        '''else:
            u = User.objects.get(username='john')
            u.set_password('albert')
            login(request, u)'''
        # Django's built-in authentication function:
        user = authenticate(username=username, password=password)

        # If we have a user
        if user:
            # Check it the account is active
            if user.is_active:
                # Log the user in.
                login(request, user)
                request.session['n'] = user.username
                if (user.is_superuser == True):
                    return render(request, 'home.html')
                    # return HttpResponse("Your account is not active.")
                # Send the user back to some page.
                # In this case their homepage.
                return render(request, 'index.html')
            else:
                # If account is not active:
                return HttpResponse("Your account is not active.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username, password))
            return HttpResponse("Invalid login details supplied.")

    else:
        # Nothing has been provided for username or password.
        return render(request, 'registration/login.html', {})


def order(request):
    if (request.method == "POST"):
        n = request.POST["dropd"]
        seq = Book.objects.get(pk=n)
        return render(request, 'view_all_book.html', {"instance": seq})
        # return HttpResponse(n)
    if (request.method == "POST"):
        o = request.POST["dropdown"]
        se = Book.objects.get(pk=o)
        return render(request, 'viewallusers.html', {"instance": se})
        # return HttpResponse(n)

    else:
        object = Book.objects.all()
        object = Book.objects.all().order_by("Book_id")
        us = UserInfo.objects.all()
        us = UserInfo.objects.all().order_by("name")
        return render(request, 'orderbook.html', {'object': object, 'us': us})


def orderbook(request, pk):
    b = Book.objects.get(pk=pk)
    u = request.session['n']
    k = User.objects.get(username=u)
    p = UserInfo.objects.get(user=k)

    dat = datetime.date.today()
    Order.dates = dat
    '''post_date = request.POST['date']
    lead_obj = Order.objects.create(dates=post_date)'''

    o = Order.objects.create(book_id=b.Book_id, bookname=b.Bookname, uid=p.uid, uname=k.username)

    # geek_object = Order.objects.create(geeks_field=d)

    o.save()
    return HttpResponse("ordered")


def userview(request):
    u = UserInfo.objects.all()
    return render(request, 'viewallusers.html', {'userlist': u})


def orderview(request):
    u = Order.objects.all()
    return render(request, 'viewallorder.html', {'orderlist': u})

def none(request):
    return render(request, "featured1/index.html")


'''def userorderview(request):
    k = Order.objects.all()
    u = request.session['n']

    return render(request, 'viewallorder.html', {'orderlist': u})'''


'''def return_book(request, pk):
    k = Order.objects.get(pk=pk)
    r = k.book_status = 'returned'


    return render(request, 'viewallorder.html', {'orderlist': r})'''
