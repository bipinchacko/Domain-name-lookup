from django import forms
from django.contrib.auth.models import User
from app1.models import Book, UserInfo, Order


class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta():
        model = User
        fields = ('username', 'email', 'password')


class Bookform(forms.ModelForm):
    class Meta:
        model = Book
        fields = '__all__'


class UserInfoForm(forms.ModelForm):
    class Meta:
        model = UserInfo
        fields = ('name', 'uid', 'age','mobileno', 'address')
        #widgets = {'status': forms.HiddenInput()}

class orderform(forms.ModelForm):
    class Meta:
        model = Order
        fields = '__all__'
