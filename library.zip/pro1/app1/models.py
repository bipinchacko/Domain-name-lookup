from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


class Book(models.Model):
    Book_id = models.AutoField(primary_key=True)
    Bookname = models.CharField(max_length=120)
    author = models.CharField(max_length=120)
    publisher = models.CharField(max_length=120)
    price = models.IntegerField()
    #pdf = models.FileField(upload_to="books/pdf")


class UserInfo(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    name = models.CharField(max_length=100)
    uid = models.AutoField(primary_key=True)
    age = models.IntegerField()
    mobileno = models.IntegerField()
    address = models.CharField(max_length=100)
    status = models.CharField(max_length=100)


    def __str__(self):
        # Built-in attribute of django.contrib.auth.models.User !
        return self.user.username


class Order(models.Model):
    order_no = models.AutoField(primary_key=True)
    book_id = models.IntegerField()
    bookname = models.CharField(max_length=100)
    uid = models.IntegerField()
    uname = models.CharField(max_length=100)
    dates = models.DateField(default=timezone.now)
