#!/usr/bin/python3 

import cgi
import cgitb
import hashlib, binascii, os
cgitb.enable()
from jinja2 import Template, Environment, FileSystemLoader

import datetime

print("Content-type: text/html")
print()
print("<br>")
# Create instance of FieldStorage
form_data = cgi.FieldStorage()

#if form_data["uname"].value=="a":
 # print("Content-type:text/html\n\n")
  #redirectURL = "http://pyb56.specind.net/login.html?msg=Invalid Password"  
  #print("<html>")
  #print("<head>")
  #print('<meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />')
  #print("</head>")
  #print ("</html>")


try:
  Username = form_data["uname"].value
 
  Password = form_data["pwd"].value
except:
  print("Content-type:text/html\n\n")
  redirectURL = "http://pyb57.specind.net/login.html?msg=Invalid Password"  
  print("<html>")
  print("<head>")
  print('<meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />')
  print("</head>")
  print ("</html>")


import pymysql
from pymysql.err import MySQLError


conn = pymysql.connect(
    db='pyb57',
    user='pyb57',
    passwd='cb783s2',
    host='localhost')
c = conn.cursor()

try:
  sql = 'SELECT salt FROM user where Username="%s"' %(Username)
  
  c.execute(sql)
  count = 0
  for row in c.fetchall():
    count = count+1
    salt = row[0]

  if count > 0 : 
    pwdhash = hashlib.pbkdf2_hmac('sha512', Password.encode('utf-8'), salt.encode('utf-8'), 100000)
    pwdhash = binascii.hexlify(pwdhash)
    Password = (salt.encode('utf-8') + pwdhash).decode('ascii')

    sql = 'SELECT Username FROM user where Username="%s" && Password="%s"' %(Username, Password)
    
    
    c.execute(sql)
    count = 0
    id = 0 
    for row in c.fetchall():
      count = count + 1;
      id = row [0]

      print("data")

    
    conn.commit()
  else:
    count = 0
    

except MySQLError as e:
  print('Got error {!r}, errno is {}'.format(e, e.args[0]))



if count>0:


  print("Content-type:text/html\n\n")
  redirectURL = "http://pyb57.specind.net/welcome.html" 
  print("<html>")
  print("<head>")
  print('<meta http-equiv="refresh" content="0;url='+str(redirectURL)+str("?Username=")+str(Username)+'" />')
  print("</head>")
  print ("</html>")
else:
  print("Content-type:text/html\n\n")
  redirectURL = "http://pyb57.specind.net/templates/incorrectpwd.html?msg=Invalid Password"  
  print("<html>")
  print("<head>")
  print('<meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />')
  print("</head>")
  print ("</html>")
