#!/usr/bin/python3 

import cgi
import cgitb
import hashlib, binascii, os
cgitb.enable()
from jinja2 import Template, Environment, FileSystemLoader

print("Content-type: text/html")
print()
print("<br>")
# Create instance of FieldStorage
form_data = cgi.FieldStorage()

# Get data from fields

#userid= form_data["uid"].value
UserID = int(form_data["Userid"].value)
First_Name = str(form_data["firstname"].value)
Last_Name = str(form_data["lastname"].value)
Username = str(form_data["username"].value)
Email= str(form_data["email"].value)
date_of_birth=str(form_data["dob"].value)
Password= str(form_data["password1"].value)



import pymysql
from pymysql.err import MySQLError

def hash_password(password):
  salt = hashlib.sha256(os.urandom(60)).hexdigest().encode('ascii')
  pwdhash = hashlib.pbkdf2_hmac('sha512', password.encode('utf-8'),salt, 100000)
  pwdhash = binascii.hexlify(pwdhash)
  return (salt + pwdhash).decode('ascii')
new_password = hash_password(Password)
salt = new_password[:64]



conn = pymysql.connect(
    db='pyb57',
    user='pyb57',
    passwd='cb783s2',
    host='localhost')
c = conn.cursor()


try:
  
   sql = 'INSERT INTO user VALUES("%d", "%s", "%s", "%s","%s","%s","%s","%s")' %(UserID,First_Name,Last_Name,Username,Email,date_of_birth,new_password,salt)
   print(sql)
   
   c.execute(sql)
   conn.commit()

except MySQLError as e:
    print('Got error {!r}, errno is {}'.format(e, e.args[0])) 
  

env = Environment(loader=FileSystemLoader('templates'))
template = env.get_template('output.html')
output_from_parsed_template = template.render(salt=salt,new_password=new_password,id=UserID,fname=First_Name,lname=Last_Name,uname=Username,email=Email,dob=date_of_birth)

try:
   fh = open("output.html", "w")
   fh.write(output_from_parsed_template)
except IOError:
   print ("<br>Error: can't find file or read data")
else:
   print ("Written content in the file successfully")

print("Content-type:text/html\n\n")
redirectURL = "http://pyb57.specind.net/output.html"
print("<html>")
print("<head>")
print('<meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />')
print("</head>")
print ("</html>")

