#!/usr/bin/python3 

import cgi
import cgitb
import hashlib, binascii, os
import requests
import time
import pymysql
from pymysql.err import MySQLError
cgitb.enable()
from jinja2 import Template, Environment, FileSystemLoader

print("Content-type: text/html")
print()
print("<br>")
# Create instance of FieldStorage

#print('Content-type:text/html\n\n')
#redirectURL = "http://abhilash.python.specind.net/project.html"
#print('<html>')
#print('  <head>')
#print('    <meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />') 
#print('  </head>')
#print('</html>')
import os
import smtplib
print("Content-Type: text/html")
print()
print("<br>")

form_data=cgi.FieldStorage()
domain_name = str(form_data["domainname"].value)
print(domain_name)
TEST_MODE = 1

connection_options = {
        'live' : {
         # IP whitelisting required
             'reseller_username': 'spectrumsofttech',
             'api_key':'a4ec416b1b7455c3871e19a0f9d902e1c8365541358f4a475617150254c3d3eec9b76358997d6883a2af59f5fdc5205e97084e1e41c0183a',
             'api_host_port': 'https://rr-n1-tor.opensrs.net:55443',
        },
        'test' : {
             # IP whitelisting not required
             'reseller_username': 'spectrumsofttech',
             'api_key':'52c74e07c41eda5e2c824528b9e4a90a9159aecad021de91c08b361a9ffd671467b15e43e5621f72b45fb1ce600641777d750f0d7ca78f1f',
             'api_host_port': 'https://horizon.opensrs.net:55443',
 
        }
}

if TEST_MODE == 1:
    connection_details = connection_options['test']
else:
    connection_details = connection_options['live']


#template = Template('Hello {{ name }}!')
#t = template.render(name='John Doe')
#print(t)
#Template('Hello {{ name }}!').stream(name='foo').dump('hello.html')

#domain_name = "nimaspectrum.com"


xml22 = '''
<?xml version='1.0' encoding='UTF-8' standalone='no' ?>
<!DOCTYPE OPS_envelope SYSTEM 'ops.dtd'>
<OPS_envelope>
<header>
    <version>0.9</version>
</header>
<body>
<data_block>
    <dt_assoc>
        <item key="protocol">XCP</item>
        <item key="action">LOOKUP</item>
        <item key="object">DOMAIN</item>
        <item key="attributes">
         <dt_assoc>
                <item key="domain">''' +domain_name+ '''</item>
         </dt_assoc>
        </item>
    </dt_assoc>
</data_block>
</body>
</OPS_envelope>
'''





#md5_obj = hashlib.md5()

#print("keyyyy",connection_details['api_key'])
#print(xml)
#ap_key1 = connection_details['api_key']
#xml_1 = xml
#all_fields = xml + ap_key1

#md5_obj.update(all_fields.encode("utf-8"))
#signature = md5_obj.hexdigest()

#print("signnn",signature)

#md5_obj = hashlib.md5()
#md5_obj.update(xml + connection_details['api_key'])
#signature = md5_obj.hexdigest()

xml_1= xml22.encode("utf-8")
con_1 = connection_details['api_key']
con_1 = con_1.encode("utf-8")
md5_obj = hashlib.md5()
md5_obj.update(xml_1 + con_1)
signature = md5_obj.hexdigest()

md5_obj = hashlib.md5()
signature=signature.encode("utf-8")
md5_obj.update(signature + con_1)
signature = md5_obj.hexdigest()


headers = {
        'Content-Type':'text/xml',
        'X-Username': connection_details['reseller_username'],
        'X-Signature':signature,
};

print("Request to {} as reseller {}:".format(connection_details['api_host_port'],connection_details['reseller_username']))
#print(xml)

r = requests.post(connection_details['api_host_port'], data = xml22, headers=headers )

print("Response:")
if r.status_code == requests.codes.ok:
    print(r.text)
   
    
else:
    print (r.status_code)
    print (r.text)

conn = pymysql.connect(
    db='pyb57',
    user='pyb57',
    passwd='cb783s2',
    host='localhost')
c = conn.cursor()

if 'taken' in r.text:
    vartime=time.ctime(time.time())
    sql='INSERT INTO report (domainnm,searchstatus,searchtime) VALUES ("%s","%s","%s")'%(domain_name,"domain taken",vartime)
    print(sql)
   
    c.execute(sql)
    conn.commit()

else:
    vartime=time.ctime(time.time())
    sql='INSERT INTO report (domainnm,searchstatus,searchtime) VALUES ("%s","%s","%s")'%(domain_name,"domain not taken",vartime)
    print(sql)
   
    c.execute(sql)
    conn.commit()


